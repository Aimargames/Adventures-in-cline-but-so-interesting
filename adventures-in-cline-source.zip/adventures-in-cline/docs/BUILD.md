# Сборка и установка

## 1. PWA (установка как приложение, работает без интернета)

Требуется **https** (или `localhost`). Файлы для публикации: `index.html`, `manifest.webmanifest`, `sw.js`, `icons/`.

- **GitHub Pages:** залей проект на GitHub и запусти workflow `deploy-pwa` (`.github/workflows/pages.yml`).
- **Локально:** `python3 -m http.server 8080` и открыть `http://localhost:8080`.

Установка у пользователя:

| Браузер | Как установить |
|---------|----------------|
| Chrome, Edge, Opera (Android и ПК) | значок установки в адресной строке или меню → «Установить приложение»; в игре есть кнопка «📲 Установить» |
| Safari (iPhone/iPad) | «Поделиться» → «На экран Домой» |
| Firefox на Android | меню → «Установить» |
| Firefox на ПК | установку PWA не поддерживает, но игра работает и открывается как обычная страница |

Чтобы выпустить новую версию, поменяй `CACHE = 'aic-v2'` в `sw.js`, иначе браузеры будут показывать закешированную.

## 2. Linux: AppImage

Нужны Node.js 18+ и сеть (скачивается Electron).

```bash
cd desktop
npm install
npm run dist
```

Результат: `desktop/dist/Adventures in cline-1.0.0-x86_64.AppImage`. Запуск:
`chmod +x *.AppImage && ./*.AppImage`. Для пробного запуска без упаковки: `npm start`.

Окно запускается с флагом `no-sandbox` (так AppImage работает на новых Ubuntu/Debian). Грузится только локальная игра.

## 3. Android: APK

Нужны Node.js 18+, JDK 17 и Android SDK (`ANDROID_HOME`). Проще всего это делает GitHub Actions (job `apk`).

```bash
cd android
npm install
node scripts/prepare.js             # копирует игру в www/
npx cap add android                 # создаёт проект android/android
node scripts/patch-android.js       # горизонтальная ориентация + иконки игры
npx cap sync android
cd android && ./gradlew assembleDebug
```

APK: `android/android/app/build/outputs/apk/debug/app-debug.apk`. Для магазина приложений нужна подписанная release-сборка
(`./gradlew assembleRelease` и свой keystore).

Альтернативы без Android SDK: опубликовать PWA на https и собрать APK через PWABuilder / Bubblewrap (Trusted Web Activity).

## 4. Автосборка в GitHub Actions

`.github/workflows/build.yml` (запуск вручную или по тегу `v*`) собирает AppImage и APK и кладёт их в Artifacts.

## 5. Иконки

Иконка нарисована кодом (`tools/make-icons.py`, нужен Pillow) и экспортируется под все платформы:

| Платформа | Где лежит |
|-----------|-----------|
| Веб / PWA | `icons/` (`favicon.ico`, `favicon.svg`, 16/32, 192, 512, maskable 512, `apple-touch-icon.png`) |
| Linux | `linux/icons/hicolor/*` (16…512 + SVG), `linux/adventures-in-cline.desktop`, `desktop/build/icons/*` для AppImage; `linux/install.sh` ставит значок в меню |
| Android | `android/res-overlay/` (adaptive: фон + передний план + монохромная для тем Android 13, круглая, обычная) и `android/store/play-store-icon-512.png` |

`node scripts/patch-android.js` сам копирует Android-иконки в проект после `npx cap add android`.

## 6. Тесты

```bash
node tests/smoke.js                 # автотест всех режимов
python3 tools/make-icons.py         # пересоздать все иконки (нужен Pillow)
```

## Статус

Игра, PWA-файлы, тест и иконки проверены. Конфигурации Electron, Capacitor и workflow написаны, но не запускались при подготовке
архива (в среде не было сети, Android SDK, appimagetool). Если сборка упадёт, смотри лог Actions и версии зависимостей в `package.json`.
