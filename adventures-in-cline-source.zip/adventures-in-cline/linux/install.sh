#!/bin/sh
# SPDX-License-Identifier: GPL-3.0-or-later
# Installs the launcher entry + icons for an AppImage (or any binary) into your user account.
# Usage: ./linux/install.sh /path/to/Adventures-in-cline.AppImage
set -e
BIN="${1:?usage: install.sh /path/to/Adventures-in-cline.AppImage}"
DIR="$(cd "$(dirname "$0")" && pwd)"
DEST="${XDG_DATA_HOME:-$HOME/.local/share}"
mkdir -p "$DEST/applications" "$DEST/icons"
cp -r "$DIR/icons/hicolor" "$DEST/icons/"
chmod +x "$BIN"
sed "s|^Exec=.*|Exec=$(realpath "$BIN")|" "$DIR/adventures-in-cline.desktop" > "$DEST/applications/adventures-in-cline.desktop"
command -v gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -f -t "$DEST/icons/hicolor" >/dev/null 2>&1 || true
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$DEST/applications" >/dev/null 2>&1 || true
echo "Installed. Look for 'Adventures in cline' in your application menu."
