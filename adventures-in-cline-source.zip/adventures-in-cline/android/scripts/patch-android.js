// SPDX-License-Identifier: GPL-3.0-or-later
// Run after `npx cap add android`:
//  1) locks the app to landscape,
//  2) installs the game launcher icons (adaptive + legacy + monochrome) from res-overlay/.
const fs = require('fs');
const path = require('path');
const main = path.join(__dirname, '..', 'android', 'app', 'src', 'main');
const manifest = path.join(main, 'AndroidManifest.xml');
if (!fs.existsSync(manifest)) { console.error('AndroidManifest.xml not found - run `npx cap add android` first'); process.exit(1); }
let x = fs.readFileSync(manifest, 'utf8');
if (!/screenOrientation/.test(x)) x = x.replace('<activity', '<activity\n            android:screenOrientation="sensorLandscape"');
fs.writeFileSync(manifest, x);
const overlay = path.join(__dirname, '..', 'res-overlay');
fs.cpSync(overlay, path.join(main, 'res'), { recursive: true, force: true });
console.log('AndroidManifest patched (sensorLandscape) and icons installed');
