// SPDX-License-Identifier: GPL-3.0-or-later
// Headless smoke test: loads index.html's script with a fake DOM and exercises every game mode.
// Run: node tests/smoke.js   (exit code 1 on failure). No dependencies.
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
let src = html.match(/<script>([\s\S]*)<\/script>/)[1].replace('requestAnimationFrame(loop);', '');

const store = {}, els = {};
const el = () => ({ style: {}, addEventListener() {}, getContext: () => new Proxy({}, { get: () => () => {}, set: () => true }),
  dataset: {}, scrollTop: 0, _h: '', value: '', set textContent(v) { this._t = v; }, get textContent() { return this._t; },
  set innerHTML(v) { this._h = v; }, get innerHTML() { return this._h; }, focus() {}, select() {},
  getBoundingClientRect() { return { left: 0, top: 0, width: 900, height: 450 }; } });
global.document = { getElementById: id => els[id] || (els[id] = el()), querySelectorAll: () => [],
  documentElement: { style: { setProperty() {} }, classList: { toggle() {}, add() {} } } };
global.addEventListener = () => {}; global.removeEventListener = () => {};
global.localStorage = { getItem: k => store[k] ?? null, setItem(k, v) { store[k] = v; } };
global.requestAnimationFrame = () => {}; global.setTimeout = () => 0; global.setInterval = () => 1; global.clearInterval = () => {};
global.innerWidth = 900; global.innerHeight = 450; global.devicePixelRatio = 1;

let fails = 0, passes = 0;
global.ok = (cond, name) => { if (cond) passes++; else { fails++; console.error('FAIL:', name); } };

const body = `
const ov = () => document.getElementById('ovt').innerHTML;
// ---- menus
showMain(); ok(ov().includes('data-act="play"') && ov().includes('data-act="ws"'), 'main menu has play + workshop');
showPlayMenu(); ok(['lvn','mp','lvf','lvt','lva','lvs','lvd'].every(a => ov().includes('data-act="' + a + '"')), 'play menu has all 7 modes');
showAbout(); ok(ov().includes('GNU General Public License'), 'about shows GPL notice');
// ---- levels
for (const l of [1, 40, 80, 81]) { begin(l); for (let i = 0; i < 200; i++) { keys.ArrowRight = 1; update(.016); draw(i * .016); } }
ok(boss && boss.max === 12 && boss.hp <= 12 && bars.length === 2 && hpk.length === 2 && pads.length === 2, 'boss level 81 has arena objects');
// ---- campaign progression + achievements
begin(1); P.x = LEN; P.y = 330; update(.016); update(.016); ok(lvl === 2 && achSet.has('l1'), 'finishing level 1 -> level 2 + achievement');
// ---- free / time / arcade / sweet
freeMode = true; begin(5); for (let i = 0; i < 100; i++) { P.inv = 0; die(); } ok(hearts === 7, 'free mode never loses hearts'); freeMode = false;
startTime(); update(.016); ok(timeMode && timeLeft < 60, 'time mode counts down');
startArc(); P.x = LEN; P.y = 330; update(.016); update(.016); ok(arcStage === 2 && arcScore >= 100, 'arcade stage up + score');
startSweet(); for (let i = 0; i < 300; i++) { keys.ArrowRight = 1; update(.016); draw(i); } ok(sweetMode && LEN > 1e8, 'sweet mode is endless');
swGen(60000); const ps = plats.slice().sort((a, b) => a.x - b.x); let reach = -1e9, maxGap = 0;
for (const p of ps) { if (reach > -1e8) maxGap = Math.max(maxGap, p.x - reach); reach = Math.max(reach, p.x + p.w); } ok(maxGap <= 100, 'sweet world gaps are jumpable');
// ---- multiplayer + duel
for (const n of [2, 3, 4]) { startMP(n, 0); for (let i = 0; i < 100; i++) { mpUpdate(.016); draw(i); } ok(MP && MP.players.length === n, 'multiplayer ' + n + ' players'); }
startDuel(); DU.cd = 0; const a = DU.players[0], b = DU.players[1]; a.y = b.y = 330; b.x = a.x + 100; a.face = 1; b.inv = 0; b.hp = 1; a.score = 80;
a.cd = 0; duelFire(a); for (let i = 0; i < 60; i++) duelUpdate(.016); ok(DU.over && DU.winner === 0, 'duel ends at 100 points');
// ---- workshop
edStart(mapNew()); ED.tool = 'G'; edPaint(10, 7); ED.tool = 'S'; edPaint(30, 7); ok(ED.cells[7][10] === 'G' && ED.cells[7][30] === 'S', 'editor paints tiles');
state = 'editSave'; document.getElementById('mn').value = 'Smoke'; edExitAfter = false; edDoSave(); ok(loadMaps().length === 1, 'map saved');
startCustom(loadMaps()[0], 'list'); ok(customMode && LEN > 1000, 'custom map starts');
P.x = 320; P.y = 320; P.vx = P.vy = 0; for (let i = 0; i < 120; i++) { keys.ArrowRight = 1; update(.016); } ok(P.x < 410, 'solid wall blocks the player');
keys.ArrowRight = 0; P.x = LEN; P.y = 320; update(.016); update(.016); ok(state === 'menu', 'custom map can be finished');
ok(mapClean({ rows: ['x'] }) === null, 'bad import rejected');
// ---- terminal + secrets + promo
showTerm(); const run = c => { document.getElementById('tout').innerHTML = ''; termRun(c); return document.getElementById('tout').innerHTML; };
ok(run('help').includes('play'), 'terminal help'); ok(run('fastfetch').includes('Adventures'), 'fastfetch'); ok(run('license').includes('GPL') || run('license').includes('GNU'), 'license command');
run('sweet'); ok(achSet.has('sweetcmd') && coinsBase === 200, 'secret sweet command pays once'); run('sweet'); ok(coinsBase === 200, 'sweet pays only once');
run('promokod cilecoin200'); ok(coinsBase === 400, 'promo coins'); run('promokod cilecoin200'); ok(coinsBase === 400, 'promo is single-use');
run('promokod "Frutiger aero"'); ok(coinsBase === 750 && ownedS.length > 1, 'promo with spaces + skin');
for (const c of ['glitch', 'cile', 'usa', 'sudo apt install opsec']) run(c); ok(achSet.has('glitch') && achSet.has('cile'), 'secret commands grant achievements');
// ---- workshop IDs, numeric codes, master commands
ok(loadMaps()[0].id === 1, 'first map gets numeric ID 1');
const code = mapEncode(loadMaps()[0]), dec = mapDecode(code);
ok(/^\\d+$/.test(code) && dec && dec.name === 'Smoke' && dec.rows.join('') === loadMaps()[0].rows.join(''), 'numeric share code round-trips');
ok(mapDecode(code.slice(0, -3) + '999') === null, 'corrupted numeric code is rejected');
showTerm(); run('master load 1'); ok(state === 'play' && customMode, 'master load 1 plays my map #1');
showTerm(); run('master load ' + groupCode(code)); ok(loadMaps().length === 2 && loadMaps()[1].id === 2 && customMode, 'master load <code> imports as ID 2 and plays');
showTerm(); ok(run('master load 999').includes('не найдена'), 'unknown ID reported');
showTerm(); run('matser create'); ok(state === 'edit', 'matser/master create opens the editor');
showTerm(); run('master'); ok(state === 'menu' && ov().includes('Мастерская'), 'master opens the workshop');
showTerm(); run('master load'); ok(ov().includes('Мои карты'), 'master load lists my maps');
// ---- Time mode awards no level achievements
achSet.delete('l2'); startTime(); P.x = LEN; P.y = 330; update(.016); update(.016); P.x = LEN; P.y = 330; update(.016); update(.016);
ok(!achSet.has('l2') && !achSet.has('l3'), 'time mode grants no level achievements');
showTerm();
run('play duel'); ok(state === 'duel', 'terminal can start duel'); ok(achTot() > 90, 'achievement total sane');
`;
try { new Function(src + body)(); } catch (e) { fails++; console.error('EXCEPTION:', e && e.stack || e); }
console.log(passes + ' passed, ' + fails + ' failed');
process.exit(fails ? 1 : 0);
