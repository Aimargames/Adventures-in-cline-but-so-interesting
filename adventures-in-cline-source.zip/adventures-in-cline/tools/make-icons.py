#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
# Draws the game icon and exports every size needed for Web (PWA), Linux (AppImage / .desktop) and Android.
# Usage: python3 tools/make-icons.py        (needs Pillow: pip install pillow)
import math, os, random
from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
def out(*p):
    path = os.path.join(ROOT, *p)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path

PLUM, PLUM2 = (42, 12, 34), (96, 30, 78)
PINK, PINK2, HOT = (255, 209, 232), (255, 143, 188), (255, 79, 154)

def lerp(a, b, t): return tuple(int(a[i] + (b[i]-a[i])*t) for i in range(3))

def star(cx, cy, r, rot=-math.pi/2):
    pts = []
    for i in range(10):
        a = rot + i*math.pi/5
        rr = r if i % 2 == 0 else r*0.42
        pts.append((cx + math.cos(a)*rr, cy + math.sin(a)*rr))
    return pts

def background(S):
    """Sky gradient, glowing star-sun and two Andes ridges (full-bleed, no transparency)."""
    img = Image.new('RGBA', (S, S))
    d = ImageDraw.Draw(img)
    for y in range(S):
        t = y/(S-1)
        c = lerp(PINK, (255, 111, 181), t/0.55) if t < 0.55 else lerp((255, 111, 181), (90, 26, 64), (t-0.55)/0.45)
        d.line([(0, y), (S, y)], fill=c+(255,))
    glow = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([S*0.30, S*0.07, S*0.70, S*0.47], fill=(255, 255, 255, 120))
    img.alpha_composite(glow.filter(ImageFilter.GaussianBlur(S*0.04)))
    d = ImageDraw.Draw(img)
    d.polygon(star(S*0.5, S*0.27, S*0.15), fill=(255, 255, 255, 255))
    far = [(0, .62), (.12, .44), (.2, .52), (.3, .36), (.42, .55), (.55, .40), (.66, .54), (.78, .34), (.9, .50), (1, .42), (1, 1), (0, 1)]
    near = [(0, .74), (.14, .58), (.26, .70), (.38, .56), (.5, .72), (.62, .57), (.76, .72), (.88, .60), (1, .70), (1, 1), (0, 1)]
    d.polygon([(x*S, y*S) for x, y in far], fill=(255, 158, 199, 255))
    d.polygon([(x*S, y*S) for x, y in near], fill=(181, 54, 122, 255))
    for (x, y) in [(.3, .36), (.55, .40), (.78, .34)]:       # snow caps
        d.polygon([(x*S, y*S), ((x-.045)*S, (y+.065)*S), ((x-.01)*S, (y+.05)*S), ((x+.02)*S, (y+.07)*S), ((x+.045)*S, (y+.065)*S)], fill=(255, 255, 255, 235))
    return img

def foreground(S, k=1.0, mono=False):
    """Corridor walls, ground, hero, enemy and coin on a transparent layer. k<1 shrinks the content (safe zones)."""
    img = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    def P(x, y): return (S*(.5+(x-.5)*k), S*(.5+(y-.5)*k))
    def col(c): return (0, 0, 0, 255) if mono else (c if len(c) == 4 else c+(255,))
    def poly(pts, c): d.polygon([P(*p) for p in pts], fill=col(c))
    def rrect(x0, y0, x1, y1, r, c):
        a, b = P(x0, y0), P(x1, y1)
        d.rounded_rectangle([a[0], a[1], b[0], b[1]], radius=S*r*k, fill=col(c))
    def circ(x, y, r, c):
        a = P(x, y); rr = S*r*k
        d.ellipse([a[0]-rr, a[1]-rr, a[0]+rr, a[1]+rr], fill=col(c))
    # walls (narrow Chile) with lighter inner edge and cracks
    if mono:                                  # themed (monochrome) icon: outlines only, no big filled blocks
        for pts in ([(.33, .10), (.385, .93)], [(.67, .10), (.615, .93)], [(.06, .10), (.33, .10)], [(.94, .10), (.67, .10)]):
            d.line([P(*pts[0]), P(*pts[1])], fill=(0, 0, 0, 255), width=int(S*.03*k))
        d.polygon([P(*p) for p in star(.5, .27, .13)], fill=(0, 0, 0, 255))
    else:
        poly([(.06, .10), (.33, .10), (.385, .93), (.06, .93)], PLUM)
        poly([(.94, .10), (.67, .10), (.615, .93), (.94, .93)], PLUM)
    if not mono:
        for sx in (1, -1):
            x0 = .33 if sx > 0 else .67
            d.line([P(.5+(x0-.5), .10), P(.5+(.385-.5)*sx if sx > 0 else .615, .93)], fill=PLUM2+(255,), width=int(S*.012*k))
        random.seed(7)
        for _ in range(7):
            y = random.uniform(.18, .8); x = random.uniform(.12, .26)
            for xx in (x, 1-x):
                d.line([P(xx, y), P(xx+.03, y+.05), P(xx-.01, y+.09)], fill=(70, 22, 58, 255), width=int(S*.008*k))
    # ground
    rrect(.33, .835, .67, .93, .01, (123, 74, 46))
    rrect(.33, .815, .67, .855, .01, PINK2)
    # soft shadow under hero
    if not mono:
        sh = Image.new('RGBA', (S, S), (0, 0, 0, 0)); sd = ImageDraw.Draw(sh)
        a, b = P(.43, .80), P(.57, .84)
        sd.ellipse([a[0], a[1], b[0], b[1]], fill=(20, 5, 15, 150))
        img.alpha_composite(sh.filter(ImageFilter.GaussianBlur(S*.006)))
        d = ImageDraw.Draw(img)
    # hero (blue, thin, mid-jump)
    rrect(.468, .54, .532, .76, .018, (47, 95, 168))
    d.line([P(.468, .60), P(.42, .66)], fill=col((47, 95, 168)), width=int(S*.018*k))       # arms
    d.line([P(.532, .60), P(.585, .54)], fill=col((47, 95, 168)), width=int(S*.018*k))
    rrect(.462, .56, .538, .59, .01, (232, 48, 80))                                           # scarf
    d.line([P(.538, .575), P(.60, .60)], fill=col((232, 48, 80)), width=int(S*.016*k))
    circ(.5, .475, .066, (243, 234, 216))
    if not mono:
        circ(.485, .47, .008, (30, 20, 30)); circ(.52, .47, .008, (30, 20, 30))
        d.arc([P(.48, .485)[0], P(.48, .485)[1], P(.52, .515)[0], P(.52, .515)[1]], 20, 160, fill=(30, 20, 30, 255), width=max(1, int(S*.006*k)))
    # enemy (black, thin)
    rrect(.585, .70, .62, .81, .01, (12, 12, 12))
    circ(.6025, .675, .036, (12, 12, 12))
    if not mono:
        circ(.592, .672, .008, (255, 255, 255)); circ(.613, .672, .008, (255, 255, 255))
    # coin
    circ(.40, .62, .034, (194, 67, 127)); circ(.40, .62, .026, (255, 79, 163))
    if not mono:
        d.ellipse([P(.388, .606)[0], P(.388, .606)[1], P(.40, .622)[0], P(.40, .622)[1]], fill=(255, 190, 220, 255))
    return img

def scene(size, kind):
    S = size*4 if size <= 512 else size*2
    if kind == 'bg':
        im = background(S)
    elif kind == 'fg':
        im = foreground(S, k=0.66)
    elif kind == 'mono':
        im = foreground(S, k=0.66, mono=True)
    else:
        im = background(S)
        im.alpha_composite(foreground(S, k=0.80 if kind == 'maskable' else 1.0))
    if kind in ('round', 'circle'):
        m = Image.new('L', (S, S), 0); md = ImageDraw.Draw(m)
        if kind == 'circle': md.ellipse([0, 0, S-1, S-1], fill=255)
        else: md.rounded_rectangle([0, 0, S-1, S-1], radius=int(S*.19), fill=255)
        im.putalpha(m)
    return im.resize((size, size), Image.LANCZOS)

# ---------------------------------------------------------------- Web / PWA
for name, size, kind in [('icon-192.png', 192, 'round'), ('icon-512.png', 512, 'round'), ('icon-maskable-512.png', 512, 'maskable'),
                         ('apple-touch-icon.png', 180, 'square'), ('favicon-32.png', 32, 'round'), ('favicon-16.png', 16, 'round')]:
    scene(size, kind).save(out('icons', name))
ico = scene(256, 'round')
ico.save(out('icons', 'favicon.ico'), sizes=[(16, 16), (32, 32), (48, 48), (64, 64)])

# ---------------------------------------------------------------- Linux
for s in (16, 24, 32, 48, 64, 96, 128, 256, 512):
    scene(s, 'round').save(out('linux', 'icons', 'hicolor', f'{s}x{s}', 'apps', 'adventures-in-cline.png'))
    scene(s, 'round').save(out('desktop', 'build', 'icons', f'{s}x{s}.png'))
scene(512, 'round').save(out('desktop', 'icon.png'))
with open(out('linux', 'adventures-in-cline.desktop'), 'w') as f:
    f.write('''[Desktop Entry]
Type=Application
Name=Adventures in cline
GenericName=Platformer
Comment=Adventures in cline but so interesting
Exec=adventures-in-cline
Icon=adventures-in-cline
Terminal=false
Categories=Game;ArcadeGame;
Keywords=game;platformer;adventure;
StartupWMClass=Adventures in cline
''')

# ---------------------------------------------------------------- Android (drop into app/src/main/res)
LEGACY = {'mdpi': 48, 'hdpi': 72, 'xhdpi': 96, 'xxhdpi': 144, 'xxxhdpi': 192}
for dens, px in LEGACY.items():
    r = f'mipmap-{dens}'
    big = round(px*108/48)                                   # adaptive icon layers are 108dp
    scene(px, 'round').save(out('android', 'res-overlay', r, 'ic_launcher.png'))
    scene(px, 'circle').save(out('android', 'res-overlay', r, 'ic_launcher_round.png'))
    scene(big, 'bg').save(out('android', 'res-overlay', r, 'ic_launcher_background.png'))
    scene(big, 'fg').save(out('android', 'res-overlay', r, 'ic_launcher_foreground.png'))
    scene(big, 'mono').save(out('android', 'res-overlay', r, 'ic_launcher_monochrome.png'))
xml = '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@mipmap/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
    <monochrome android:drawable="@mipmap/ic_launcher_monochrome"/>
</adaptive-icon>
'''
for n in ('ic_launcher.xml', 'ic_launcher_round.xml'):
    open(out('android', 'res-overlay', 'mipmap-anydpi-v26', n), 'w').write(xml)
scene(512, 'square').convert('RGB').save(out('android', 'store', 'play-store-icon-512.png'))

# ---------------------------------------------------------------- big preview + SVG
scene(1024, 'round').save(out('icons', 'icon-1024.png'))
with open(out('icons', 'favicon.svg'), 'w') as f:
    f.write('''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
<defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffd1e8"/><stop offset=".55" stop-color="#ff6fb5"/><stop offset="1" stop-color="#5a1a40"/></linearGradient>
<radialGradient id="s" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#fff" stop-opacity=".9"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient></defs>
<rect width="100" height="100" rx="19" fill="url(#g)"/>
<circle cx="50" cy="27" r="22" fill="url(#s)"/>
<path d="M50 12l4.400 9.400 10.200 1.200-7.600 7 2 10.100L50 34.600 41 39.700l2-10.100-7.600-7 10.200-1.200z" fill="#fff"/>
<path d="M0 62l12-18 8 8 10-16 12 19 13-15 11 14 12-20 12 16V100H0z" fill="#ff9ec7"/>
<path d="M0 74l14-16 12 12 12-14 12 16 12-15 14 15 12-12 12 10V100H0z" fill="#b5367a"/>
<path d="M6 10h27l5.500 83H6zM94 10H67l-5.500 83H94z" fill="#2a0c22"/>
<rect x="33" y="81.500" width="34" height="11.500" rx="1" fill="#7b4a2e"/><rect x="33" y="81.500" width="34" height="4" rx="1" fill="#ff8fbc"/>
<ellipse cx="50" cy="82" rx="7" ry="2" fill="#140a0f" opacity=".5"/>
<rect x="46.800" y="54" width="6.400" height="22" rx="1.800" fill="#2f5fa8"/>
<path d="M46.800 60L42 66M53.200 60L58.500 54" stroke="#2f5fa8" stroke-width="1.800" stroke-linecap="round"/>
<rect x="46.200" y="56" width="7.600" height="3" rx="1" fill="#e83050"/><path d="M53.800 57.500L60 60" stroke="#e83050" stroke-width="1.600"/>
<circle cx="50" cy="47.500" r="6.600" fill="#f3ead8"/><circle cx="48.500" cy="47" r=".8" fill="#1e141e"/><circle cx="52" cy="47" r=".8" fill="#1e141e"/>
<rect x="58.500" y="70" width="3.500" height="11" rx="1" fill="#0c0c0c"/><circle cx="60.250" cy="67.500" r="3.600" fill="#0c0c0c"/>
<circle cx="59.200" cy="67.200" r=".8" fill="#fff"/><circle cx="61.300" cy="67.200" r=".8" fill="#fff"/>
<circle cx="40" cy="62" r="3.400" fill="#c2437f"/><circle cx="40" cy="62" r="2.600" fill="#ff4fa3"/></svg>''')
with open(out('linux', 'icons', 'hicolor', 'scalable', 'apps', 'adventures-in-cline.svg') if os.makedirs(os.path.dirname(out('linux', 'icons', 'hicolor', 'scalable', 'apps', 'adventures-in-cline.svg')), exist_ok=True) is None else '', 'w') as f:
    f.write(open(out('icons', 'favicon.svg')).read())
print('icons written')
