// SPDX-License-Identifier: GPL-3.0-or-later
// Minimal Electron shell: opens the game (a single static HTML file) in a window.
const { app, BrowserWindow, Menu, shell } = require('electron');
const path = require('path');

// AppImage builds on recent Ubuntu/Debian cannot use the setuid sandbox helper.
// The window only ever loads the bundled local game, so this is acceptable here.
if (process.platform === 'linux') app.commandLine.appendSwitch('no-sandbox');

function createWindow() {
  Menu.setApplicationMenu(null);
  const win = new BrowserWindow({
    width: 1280, height: 720, minWidth: 640, minHeight: 360,
    backgroundColor: '#5a1a40', autoHideMenuBar: true,
    title: 'Adventures in cline but so interesting',
    icon: path.join(__dirname, 'icon.png'),
    webPreferences: { contextIsolation: true, nodeIntegration: false }
  });
  win.loadFile(path.join(__dirname, 'app', 'index.html'));
  // external links (license, Telegram...) open in the system browser
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && input.key === 'F11') { win.setFullScreen(!win.isFullScreen()); e.preventDefault(); }
  });
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
